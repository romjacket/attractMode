### Attrac-Man - Sample Attract-Mode Layout ###

Based on the arcade game "Pac-Man" designed by Toru Iwatani and first 
released by Namco in 1980.

Special thanks to Jamey Pittman for "The Pac-Man Dossier" resource.

http://home.comcast.net/~jpittman2/pacman/pacmandossier.html

#### Configuration ####

The keys used to control Attrac-Man and set game speed can be configured
by editing the file "layout.nut".
